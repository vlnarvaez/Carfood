<!DOCTYPE html>
<?php

session_start();

if($_SESSION["miSession"]['TIPO']==2){
    
    ?>
    <div>
        <p><font color="black ">Bienvenido: <?php echo $_SESSION["miSession"]['USUARIO'];?></font>
        <font color="#FFFFFF"> <?php echo " <a href='cerrarsesion.php'>cerrar session</a>";?></font></p>
    </div>
    <?php
    
}else{
    header('Location: logeo.php?error=1');
}
?>
<a href='cerrarsesion.php'>cerrar session</a>

<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <LINK REL=StyleSheet HREF="css/chef.css" TYPE="text/css" MEDIA=screen>

        <title>Elevator - Multipurpose Bootstrap Theme</title>

    </head>
    
    <body>
        
        <!-- Start Logo Section -->
        <center>
            <img src="images/logo.png" style="width:20%;height:20%;border-style:groove;border-color:#000;border-width: 15px;">
            <hr>
        </center>
        
        <!-- End Logo Section -->
       
        
        
        
        <!-- Start Portfolio Section -->
        <div class="section-modal modal fade" id="portfolio-modal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                
                <div class="container">

                    <div class="container">
        <div class="row">
            <div class="[ col-xs-12 col-sm-offset-2 col-sm-8 ]">
                <ul class="event-list">
                    <li>
                        <time datetime="2014-07-20 0000">
                            <span class="day">1</span>
                            <span class="month">Mesa</span>
                        </time>

                        <img alt="Independence Day" src="http://www.unionjalisco.mx/sites/default/files/imagecache/v2_660x370/comidajal.jpg" />
                        <div class="info">
                            <h2 class="title">Canelones</h2>
                            <p class="desc">Pasta, Carne, queso, cebolla</p>
                            <p class="observaciones">Sin cebolla</p>
                        </div>
                    </li>

                    <li>
                        <time datetime="2014-07-20 0000">
                            <span class="day">1</span>
                            <span class="month">Mesa</span>
                        </time>

                        <img alt="Independence Day" src="http://www.gourmet.cl/wp-content/uploads/2011/04/camarones_al_ajillo_y_calamares.jpg" />
                        <div class="info">
                            <h2 class="title">Camarones al Ajíllo</h2>
                            <p class="desc">Camaron, salsa, lechuga</p>
                            <p class="observaciones"></p>
                        </div>
                    </li>


                    <li>
                        <time datetime="2014-07-20 0000">
                            <span class="day">2</span>
                            <span class="month">Mesa</span>
                        </time>

                        <img alt="Independence Day" src="http://i.anunciosya.com.mx/i-a/If5G-1.jpg" />
                        <div class="info">
                            <h2 class="title">Café Gourmet</h2>
                            <p class="desc"> Café de máquina, crema, azucar</p>
                            <p class="observaciones">Sin azucar</p>
                        </div>
                    </li>

                    <li>
                        <time datetime="2014-07-20 0000">
                            <span class="day">3</span>
                            <span class="month">Mesa</span>
                        </time>

                        <img alt="Independence Day" src="http://www.fahrenheitmagazine.com/wp-content/uploads/2015/04/1-cheese-cake-543x350.jpg" />
                        <div class="info">
                            <h2 class="title">Tiramisú</h2>
                            <p class="desc">Galleta, fresa, Crema </p>
                            <p class="observaciones"></p>
                        </div>
                    </li>

                </ul>
            </div>
        </div>
    </div>

                </div>
                
            </div>
        </div>
        <!-- End Portfolio Section -->
        
       
                
            </div>
        </div>
        <!-- End Testimonial Section -->
        
    </body>
    
</html>