<?php

$cone=mysql_connect("localhost","root","") or die ('No hay conexion a la base de datos');
$db=mysql_select_db('db_carfood',$cone) or die ('no existe la base de datos');

?>



	
		
	

