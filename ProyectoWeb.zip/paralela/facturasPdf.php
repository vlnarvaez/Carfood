<?php
require('conexion.php');
require('fpdf/fpdf.php');
$ceduEnv=$_POST['cedula'];
session_start();

$consul=mysql_query("SELECT * FROM cliente");
$puerta='continuar';
while ($filas=mysql_fetch_array($consul)and $puerta='continuar' ) {
	$CEDULA=$filas['CEDULA'];
	$NOMBRES=$NOMBRES=$filas['NOMBRES'];
	$APELLIDOS=$filas['APELLIDOS'];
	$TELEFONO=$filas['TELEFONO'];
	$EMAIL=$filas['EMAIL'];
	
	
	if($ceduEnv==$CEDULA){	
		$miCliente=array('CEDULA' => $CEDULA, 'NOMBRES' => $NOMBRES, 'APELLIDOS' => $APELLIDOS, 'TELEFONO' => $TELEFONO, 'EMAIL' => $EMAIL);
		$_SESSION['miCliente']=$miCliente; 
		


	$pdf = new FPDF();
	$pdf->AddPage();
	$pdf->SetFont('Arial', '', 10);
	$pdf->Image('images/logo.png' , 90 ,8, 20 , 23,'PNG');
	$pdf->Cell(150, 10, '', 0);
	#$pdf->Cell(80, 10, '"CARFOOD"', 0);
	$pdf->SetFont('Arial', '', 9);
	$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
	$pdf->Ln(15);
	$pdf->SetFont('Arial', 'B', 11);
	$pdf->Ln(20);
	$pdf->Cell(80, 8, '', 0);
	$pdf->Cell(100, 8, 'FACTURA', 0);
	$pdf->Ln(23);
	$pdf->SetFont('Arial', '', 8);
	//CONSULTA

	if($consulta = mysql_query("SELECT * FROM cliente where CEDULA=$ceduEnv")){
	
	$consulta2 = mysql_fetch_array($consulta);

	$pdf->Cell(20, 8, 'Cedula', 0);
	$pdf->Cell(20, 8,$consulta2['CEDULA'], 0);
	$pdf->Ln(4);
	$pdf->Cell(20, 8, 'Nombre', 0);	
	$pdf->Cell(20, 8,$consulta2['NOMBRES'], 0);
	$pdf->Ln(4);
	$pdf->Cell(20, 8, 'Apellido', 0);
	$pdf->Cell(20, 8,$consulta2['APELLIDOS'], 0);
	$pdf->Ln(4);	
	$pdf->Cell(20, 8, 'Telefono', 0);
	$pdf->Cell(20, 8,$consulta2['TELEFONO'], 0);
	$pdf->Ln(4);	
	$pdf->Cell(20, 8, 'Email', 0);
	$pdf->Cell(20, 8,$consulta2['EMAIL'], 0);
	$pdf->Ln(4);
	
	$pdf->SetFont('Arial', 'B', 11);
	$pdf->Ln(20);
	$pdf->Cell(70, 8, '', 0);
	$pdf->Cell(100, 8, 'LISTADO DE PRODUCTOS', 0);
	$pdf->Ln(23);
	$pdf->SetFont('Arial', 'B', 8);
	$pdf->Cell(15, 8, 'Item', 1);
	$pdf->Cell(80, 8, 'Nombre', 1);
	$pdf->Cell(40, 8, 'Detalle', 1);
	$pdf->Cell(25, 8, 'Precio', 1);

	$pdf->Ln(8);
	$pdf->SetFont('Arial', '', 8);
	$item = 0;
	$totaluni = 0;
	if($consulta3 = mysql_query("SELECT * FROM platos where CEDULA=$ceduEnv")){
		$consulta4 = mysql_fetch_array($consulta3);
		$item = $item+1;
		$totaluni = $totaluni + $consulta4['PRECIO'];
		$pdf->Cell(15, 8, $item, 1);
		$pdf->Cell(80, 8,$consulta4['NOMBRE'], 1);
		$pdf->Cell(40, 8, $consulta4['DETALLE'], 1);
		$pdf->Cell(25, 8, '$ '.$consulta4['PRECIO'], 1);
		$pdf->Ln(8);
	}

	$pdf->SetFont('Arial', 'B', 8);
	$pdf->Cell(129,8,'',0);
	$pdf->Cell(31,8,'Total: $ '.$totaluni,1);
	$pdf->Ln(60);
	$pdf->SetFont('Arial', '', 8);
	#$pdf->Cell(float 0 [, float 10 [, string texto firmas [, mixed 1 [, int 1 [, string c [, boolean false [, mixed link]]]]]]])
	$pdf->Cell(0,8,'_ _ _ _ _ _ _ _ _ _                      _ _ _ _ _ _ _ _ _ _' ,0,2,'C');
	$pdf->Cell(0,8,'  Roger jimbo                             Encargado' ,0,2,'C');

	$pdf->Output();	
}

	
}else{
	$puerta='salir';

	}
}
?>