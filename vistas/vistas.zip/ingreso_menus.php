<html><meta charset="UTF-8">
<head>
	<title>Ingreso menus</title>
	<LINK REL=StyleSheet HREF="css/estilos.css" TYPE="text/css" MEDIA=screen>
		<script> 
function abrir(url) { 
open(url,'','top=200,left=500,width=400,height=250') ; 
} 
</script> 

</head>
<body >
	<div id="casillas">

		<h1>Registro de nuevo Menu</h1>
		 <LI><a  href="javascript:abrir('plato.php')">Nuevo Plato</a> 
		 <LI><a  href="menu.php">Nuevo Menu</a> 
	</div>

</body>
</html>