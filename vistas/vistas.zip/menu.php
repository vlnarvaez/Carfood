<html><meta charset="UTF-8">
<head>
	<title>Nuevo Menu</title>
	<LINK REL=StyleSheet HREF="css/estilos.css" TYPE="text/css" MEDIA=screen>
</head>

<body >
	<div id="nombre">Estructura del Menu</div>
	<div id="tabla">
	<TABLE BORDER=1 WIDTH=300>

		<TR>
			<TD WIDTH=100>Tipo
			</TD>

			<TD WIDTH=100>Plato1
			</TD>
			<TD WIDTH=100>Detalle Plato1
			</TD>
			<TD WIDTH=100>Plato2
			</TD>
			<TD WIDTH=100>Detalle Plato2
			</TD>
			<TD WIDTH=100>Bebida
			</TD>
			<TD WIDTH=100>Detalle Bebida
			</TD>
			<TD WIDTH=100>Precio
			</TD>
		</TR>

		<TR>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>Desayuno</OPTION>
				  <OPTION>Almuerzo</OPTION>
				  <OPTION>Merienda</OPTION>
				  <OPTION>Otro</OPTION>
				</SELECT>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>jugo</OPTION>
				  <OPTION>soda</OPTION>
				  <OPTION>batido</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>Desayuno</OPTION>
				  <OPTION>Almuerzo</OPTION>
				  <OPTION>Merienda</OPTION>
				  <OPTION>Otro</OPTION>
				</SELECT>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>jugo</OPTION>
				  <OPTION>soda</OPTION>
				  <OPTION>batido</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>Desayuno</OPTION>
				  <OPTION>Almuerzo</OPTION>
				  <OPTION>Merienda</OPTION>
				  <OPTION>Otro</OPTION>
				</SELECT>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>jugo</OPTION>
				  <OPTION>soda</OPTION>
				  <OPTION>batido</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>Desayuno</OPTION>
				  <OPTION>Almuerzo</OPTION>
				  <OPTION>Merienda</OPTION>
				  <OPTION>Otro</OPTION>
				</SELECT>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>jugo</OPTION>
				  <OPTION>soda</OPTION>
				  <OPTION>batido</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>Desayuno</OPTION>
				  <OPTION>Almuerzo</OPTION>
				  <OPTION>Merienda</OPTION>
				  <OPTION>Otro</OPTION>
				</SELECT>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>jugo</OPTION>
				  <OPTION>soda</OPTION>
				  <OPTION>batido</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>Desayuno</OPTION>
				  <OPTION>Almuerzo</OPTION>
				  <OPTION>Merienda</OPTION>
				  <OPTION>Otro</OPTION>
				</SELECT>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>jugo</OPTION>
				  <OPTION>soda</OPTION>
				  <OPTION>batido</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>Desayuno</OPTION>
				  <OPTION>Almuerzo</OPTION>
				  <OPTION>Merienda</OPTION>
				  <OPTION>Otro</OPTION>
				</SELECT>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>jugo</OPTION>
				  <OPTION>soda</OPTION>
				  <OPTION>batido</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>Desayuno</OPTION>
				  <OPTION>Almuerzo</OPTION>
				  <OPTION>Merienda</OPTION>
				  <OPTION>Otro</OPTION>
				</SELECT>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>jugo</OPTION>
				  <OPTION>soda</OPTION>
				  <OPTION>batido</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>Desayuno</OPTION>
				  <OPTION>Almuerzo</OPTION>
				  <OPTION>Merienda</OPTION>
				  <OPTION>Otro</OPTION>
				</SELECT>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>jugo</OPTION>
				  <OPTION>soda</OPTION>
				  <OPTION>batido</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>Desayuno</OPTION>
				  <OPTION>Almuerzo</OPTION>
				  <OPTION>Merienda</OPTION>
				  <OPTION>Otro</OPTION>
				</SELECT>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>jugo</OPTION>
				  <OPTION>soda</OPTION>
				  <OPTION>batido</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>Desayuno</OPTION>
				  <OPTION>Almuerzo</OPTION>
				  <OPTION>Merienda</OPTION>
				  <OPTION>Otro</OPTION>
				</SELECT>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>

			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>pollo</OPTION>
				  <OPTION>sopa</OPTION>
				  <OPTION>carne</OPTION>
				  <OPTION>juego</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<SELECT NAME="Idioma">
				  <OPTION>jugo</OPTION>
				  <OPTION>soda</OPTION>
				  <OPTION>batido</OPTION>
				</SELECT>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
			<TD WIDTH=100>
				<TEXTAREA></TEXTAREA>
			</TD>
		</TR>

	</TABLE>
	</div>
</body>
</html>